#include <jni.h>
#include "android/log.h"
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define LOG_TAG "MyTag"
#define LOGV(...)   __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__)
static int cnt=0;
static int print_cnt=0;
static int set_record=0;
static unsigned char save[33];
static unsigned char tmp[33];
static unsigned char prev_data[9];
int set_play=0;

jint JNICALL Java_org_example_ndk_NDKExam_add(JNIEnv *env, jobject this,jint btn_set)
{
	//LOGV("log test %d\n", 1234);
	unsigned char get_data[9];

	int term;
	term=0;


	int i;

	int fd=open("/dev/dev_lib",O_RDWR);
	if(fd<0)
	{
		return -1;
	}

	int length;
	length=sizeof(get_data);
	//LOGV("log test %d", length);
	read(fd,get_data,length);

	jclass cls = (*env)->GetObjectClass(env,this);

	if(get_data[1] && !prev_data[1])
	{
		set_play=1;
		LOGV("log test %d", get_data[1]);
	}
	else if(get_data[0] && !prev_data[0])
	{
		term=1;
		LOGV("log test %d", get_data[0]);
	}
	else if(get_data[2] && !prev_data[2])
	{
		set_record=1-set_record;
		LOGV("log test %d", get_data[2]);
		if(set_record)
		{
			for(i=0;i<33;i++)
				tmp[i]=' ';
		}
		if(!set_record)
		{
			cnt=0;
			for(i=0;i<33;i++)
			{
				save[i]=tmp[i];
				//LOGV("btn_set : %d\n",save[i]);
				tmp[i]=' ';
			}
			write(fd,save,sizeof(save));
		}
		//print_cnt=0;
	}

	if(print_cnt==32)
	{
		print_cnt=0;
		set_play=0;
	}

	//LOGV("log test %d", 1234);
	jfieldID fidnumber=(*env)->GetFieldID(env,cls,"set_play","I");

	(*env)->SetIntField(env,this,fidnumber,set_play);

	if(set_record)
	{
//		LOGV("record\n");
		if(cnt<33 && btn_set>=1&&btn_set<=8) {
			LOGV("btn_set : %d\n",btn_set);
			tmp[cnt++]= btn_set +'0';
		}
	}
	if(term)
	{
		LOGV("Terminal\n");
		jfieldID fidnumber = (*env)->GetFieldID(env,cls,"terminate","I");
		(*env)->SetIntField(env,this,fidnumber,1);
	}

	//LOGV("log test %d", 1234);
	memcpy(prev_data,get_data,9);

	close(fd);
	if(set_play)
		return save[print_cnt++]-'0';
	else
		return 0;
}

