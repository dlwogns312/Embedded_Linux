package org.example.ndk;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class NDKExam extends Activity {
	public native int add(int btn_set);
	int terminate=0;
	int set_play=0;
	MediaPlayer mp1,mp2,mp3,mp4,mp5,mp6,mp7,mp8;
	Button low_do,re,mi,pa,sol,la,si,high_do;
	OnClickListener lt1,lt2,lt3,lt4,lt5,lt6,lt7,lt8;
	int btn_set=0;
	
	class BGMThread extends Thread
	{
		
		char[] arr= new char[33];
		BGMThread(){}
		
		public void run()
		{
			while(terminate==0)
			{
				NDKExam.this.runOnUiThread(new Runnable(){
					@Override
					public void run()
					{
						//System.out.println(set_play);
						int k=add(btn_set);
						//System.out.println(k);
					
						if(set_play==1)
						{
								if(k==1)
								{
									mp1.start();
									//for(int j=0;j<10000;j++);
									//mp1.pause();
								}
								else if(k==2)
								{
									mp2.start();
									//for(int j=0;j<10000;j++);
									//mp2.pause();
								}
								else if(k==3)
								{
									mp3.start();
									//for(int j=0;j<10000;j++);
									//mp3.pause();
								}
								else if(k==4)
								{
									mp4.start();
									//for(int j=0;j<10000;j++);
									//mp4.pause();
								}
								else if(k==5)
								{
									mp5.start();
									//for(int j=0;j<10000;j++);
									//mp5.pause();
								}
								else if(k==6)
								{
									mp6.start();
									//for(int j=0;j<10000;j++);
									//mp6.pause();
								}
								else if(k==7)
								{
									mp7.start();
									//for(int j=0;j<10000;j++);
									//mp7.pause();
								}
								else if(k==8)
								{
									mp8.start();
									//for(int j=0;j<10000;j++);
									//mp8.pause();
								}
								try{
									Thread.sleep(300);
								} catch(InterruptedException e)
									{
										e.printStackTrace();
									}
								
						
						}
						btn_set=0;
					}
				});
				
				try{
					Thread.sleep(20);
				} catch(InterruptedException e)
					{
						e.printStackTrace();
					}
				
				
			}
		}
	}
	
	BGMThread bgmthread;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       
        //System.loadLibrary("ndk-exam");

        low_do=(Button)findViewById(R.id.btn1);
        re=(Button)findViewById(R.id.btn2);
        mi=(Button)findViewById(R.id.btn3);
        pa=(Button)findViewById(R.id.btn4);
        sol=(Button)findViewById(R.id.btn5);
        la=(Button)findViewById(R.id.btn6);
        si=(Button)findViewById(R.id.btn7);
        high_do=(Button)findViewById(R.id.btn8);
        
        mp1=MediaPlayer.create(this, R.raw.low_do);
        mp2=MediaPlayer.create(this, R.raw.re);
        mp3=MediaPlayer.create(this, R.raw.mi);
        mp4=MediaPlayer.create(this, R.raw.pa);
        mp5=MediaPlayer.create(this, R.raw.sol);
        mp6=MediaPlayer.create(this, R.raw.la);
        mp7=MediaPlayer.create(this, R.raw.si);
        mp8=MediaPlayer.create(this, R.raw.high_do);
        
        lt1=new OnClickListener()
        {
        
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp1.start();
        		btn_set=1;
        	}
        };
        low_do.setOnClickListener(lt1);
        
        lt2=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp2.start();
 
        		btn_set=2;
        	}
        };
        re.setOnClickListener(lt2);
        
        lt3=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp3.start();
        	
        		btn_set=3;
        	}
        };
        mi.setOnClickListener(lt3);
        
        lt4=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp4.start();
        		
        		btn_set=4;
        	}
        };
        pa.setOnClickListener(lt4);
        
        lt5=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp5.start();
        		
        		btn_set=5;
        	}
        };
        sol.setOnClickListener(lt5);

        lt6=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp6.start();
        		
        		btn_set=6;
        	}
        };
        la.setOnClickListener(lt6);
        
        lt7=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp7.start();
        		
        		btn_set=7;
        	}
        };
        si.setOnClickListener(lt7);
        
        lt8=new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		if(terminate==0)
        			mp8.start();
        		
        		btn_set=8;
        	}
        };
        high_do.setOnClickListener(lt8);
        
        System.loadLibrary("ndk-exam");
        bgmthread=new BGMThread();
        bgmthread.start();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	


}
