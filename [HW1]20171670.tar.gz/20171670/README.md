//20171670 Embedded System Software

//Assignment 1 - Device control and IPC